Cars:
- jeep
- pickup
- sports car
- super car
- muscle car
- electric car
- station wagon
- economy car
- compact car
- cop car

Trucks:
- short flat bed
- long flat bed
- short straight truck
- long straight truck
- bus
- trash truck
- semi truck
- tanker truck
- fire truck
- ambulance
- armored bank car
- swat APC

Motorcycles:
- street bike
- dirt bike
- chopper
- cruising bike

Construction equipment:
- excavator
- dozer
- crane
- grader
- backhoe
- loader
- roller
- dump truck
- cement truck
