# TSLM (The Secret Life of Mallory)
### A Hacker RPG
=================================================

A hacking RPG where the you live your normal life by day, and crawl through the cracks of the internet by night exploring the dichotomy of our interconnected world.

##Design Premise: 
TSLM is a pokemon style 3d sandbox world populated with 2d people, vehicles, & buildings built ontop of a comprehensive idle game that simulates a small slice of the real world. A simulated internet connects the devices people carry to the computing systems in every home, business and institution giving the player both a physical and digital way to move about the world. Anything is possible but players are not free from the consequences of their actions.

## Tag Line Ideas 
A Hacking RPG, A Hacker RPG, A Hack n Crash RPG

## Graphics Description
8bit style 2d art in a 3d world

## World Description
12 cities across 2 continents and an island
a dozen or so professions
planes(unhackable), trains, cars, trucks, ships
npcs with their own lives, and computer devices move through the world

## Gameplay
A hacking RPG where the you liveyour normal life by day, and crawl through the cracks of the internet by night exploring the dichotomy of our interconnected world.  Player switches back and forth through Physical world, and anthropomorphized digital world.  Solving problems by hacking the digital world in order to affect the physical world.  puzzles should be solvable in the physical world, the digital world or both( a combined approch of digital and physical should most often be the best approach)  for game+ there should be several gripping naratives that can be solved through REPL real life programming to solve in game problems.

## Possible Technologies:
• https://www.midjourney.com/ graphic art generation

• Phaser game engine https://phaser.io/ alternative game engine


## Languages: 
javascript/typescript
html
css

## Inspiring games
Star Dew Valley
Pokemon
BitBurner

bitburner https://github.com/danielyxie/bitburner
